# NAMC Blog

A modern, responsive static blog by Viva Yannick with red, white, and black branding.

## Features

✅ **Modern Design** - Red (#DC143C), white, and black color scheme  
✅ **Responsive** - Mobile, tablet, and desktop optimized  
✅ **Fast** - No dependencies, pure HTML/CSS  
✅ **GitHub Pages Ready** - Deploy directly from your repo  
✅ **Easy to Update** - Simple file structure for managing posts  

## Project Structure

```
NAMC-blog/
├── index.html
├── styles.css
├── README.md
├── posts/
│   ├── getting-started.html
│   ├── web-design-tips.html
│   └── digital-creativity.html
└── .gitignore
```

## Quick Start

1. **Clone/Download** this repository
2. **Open** `index.html` in your browser
3. **For local testing**: `python -m http.server 8000`

## Deploy to GitHub Pages

1. Push this repo to GitHub
2. Go to Settings → Pages
3. Select `main` branch as source
4. Your site will be live at: `https://yourusername.github.io/NAMC-blog`

## Adding New Posts

1. Create a new HTML file in the `posts/` folder
2. Use existing posts as templates
3. Add a link in `index.html` under the posts grid

## Customization

- **Colors**: Edit CSS variables in `styles.css`
- **Author**: Search and replace "Viva Yannick" with your name
- **Content**: Edit hero section, about section, and post content

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## License

MIT License - Feel free to use this template!

---

**NAMC Blog © 2026 | By Viva Yannick**